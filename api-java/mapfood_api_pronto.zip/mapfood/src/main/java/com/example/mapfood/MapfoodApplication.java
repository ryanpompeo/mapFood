package com.example.mapfood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapfoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(MapfoodApplication.class, args);
	}

}
