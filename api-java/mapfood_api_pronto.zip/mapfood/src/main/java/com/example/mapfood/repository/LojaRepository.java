package com.example.mapfood.repository;

import com.example.mapfood.model.Loja;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LojaRepository extends JpaRepository<Loja, Integer> {
}
